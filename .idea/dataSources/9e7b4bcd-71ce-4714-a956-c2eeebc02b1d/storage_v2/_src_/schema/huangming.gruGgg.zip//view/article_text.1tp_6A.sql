create view article_text as
select `huangming`.`article`.`text` AS `text`
from `huangming`.`article`;

