create procedure id()
begin
  select id
  from article;  
end;

