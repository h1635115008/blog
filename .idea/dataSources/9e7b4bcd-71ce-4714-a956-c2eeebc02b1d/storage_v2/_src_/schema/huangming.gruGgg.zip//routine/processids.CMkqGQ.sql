create procedure processids()
begin
  declare done boolean default 0;
  declare i int default 0;
  #declare id int;
  #declare ids cursor
  #for
  #select id from article;
  #declare continue handler for sqlstate '02000' set done=1;
  #open ids;
  set autocommit = 0;
  repeat
    set i = i+1;
    #fetch ids into id;
    insert into ida(id)
    values(i);
    if(i > 10000000) then
      set done = 1;
    end if;
  until done end repeat;
  commit;
  #close ids;
end;

