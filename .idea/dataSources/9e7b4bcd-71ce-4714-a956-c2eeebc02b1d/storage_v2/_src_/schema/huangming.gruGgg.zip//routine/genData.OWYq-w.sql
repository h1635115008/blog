create procedure genData()
begin
    declare i int;
    set i = 1;
    set autocommit = 0;
    while (i <= 10000000) do
            insert into t(id, k) value (i, i);
            set i = i + 1;
        end while ;
    commit;
end;

